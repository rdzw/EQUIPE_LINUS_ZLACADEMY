#!/bin/bash

zip -r "Bot-PedidosdeEmprestimo(POC).zip" * -x "Bot-PedidosdeEmprestimo(POC).zip"